// chess-server/server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Chess } = require('chess.js');

const app = express();
const server = http.createServer(app);

const PORT = process.env.PORT || 3000; // Define a porta para 3000

// Configura o Socket.IO para permitir conexões de qualquer origem (CORS)
const io = new Server(server, {
    cors: {
        origin: "*", // CUIDADO: Em produção, defina isso para o domínio exato do seu frontend.
        methods: ["GET", "POST"]
    }
});

let games = {}; // Objeto para armazenar as partidas ativas
let pendingPlayer = null; // Armazena um jogador esperando por uma partida

io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    // Lógica de emparelhamento simples: conecta dois jogadores.
    if (pendingPlayer) {
        const gameId = `game-${pendingPlayer.id}-${socket.id}`;
        const chessGame = new Chess();
        games[gameId] = {
            players: {
                white: pendingPlayer.id,
                black: socket.id
            },
            board: chessGame, // Instância do jogo de xadrez
        };

        // Junta os dois sockets na mesma sala do Socket.IO
        socket.join(gameId);
        pendingPlayer.socket.join(gameId);

        // Notifica os jogadores que a partida foi encontrada
        pendingPlayer.socket.emit('matchFound', {
            gameId: gameId,
            playerColor: 'w', // O primeiro jogador é sempre branco
            opponentId: socket.id
        });
        socket.emit('matchFound', {
            gameId: gameId,
            playerColor: 'b', // O segundo jogador é sempre preto
            opponentId: pendingPlayer.id
        });

        console.log(`Match found: ${gameId} (White: ${pendingPlayer.id}, Black: ${socket.id})`);
        pendingPlayer = null; // Reseta o jogador pendente

    } else {
        // Se não houver jogador pendente, este jogador fica esperando
        pendingPlayer = {
            id: socket.id,
            socket: socket
        };
        socket.emit('waitingForOpponent', 'Aguardando um oponente...');
        console.log(`Player ${socket.id} is waiting for an opponent.`);
    }

    // Escuta por eventos de 'move' (movimento de peça)
    socket.on('move', (data) => {
        const { gameId, from, to, promotion, playerColor } = data;
        const game = games[gameId];

        if (!game) {
            console.warn(`Partida ${gameId} não encontrada para o movimento.`);
            return;
        }

        const chessBoard = game.board; // Pega a instância do jogo de xadrez

        // Verifica se é o turno do jogador que enviou o movimento
        if ((playerColor === 'w' && chessBoard.turn() !== 'w') || (playerColor === 'b' && chessBoard.turn() !== 'b')) {
            console.log(`Não é o turno de ${playerColor} na partida ${gameId}.`);
            socket.emit('invalidMove', 'Não é o seu turno!');
            return;
        }

        // Verifica se a peça pertence ao jogador
        const piece = chessBoard.get(from);
        if (!piece || piece.color !== playerColor) {
            console.log(`Jogador ${socket.id} tentou mover a peça do oponente ou um quadrado vazio.`);
            socket.emit('invalidMove', 'Você não pode mover essa peça.');
            return;
        }

        try {
            // Tenta fazer o movimento na biblioteca chess.js
            const moveResult = chessBoard.move({ from, to, promotion });

            if (moveResult) {
                // Se o movimento for válido, emite para todos na sala
                io.to(gameId).emit('moveMade', {
                    fen: chessBoard.fen(), // Envia o FEN atualizado do tabuleiro
                    lastMove: moveResult, // O último movimento
                    turn: chessBoard.turn() // De quem é o próximo turno
                });
                console.log(`Movimento realizado na partida ${gameId}: ${from}-${to}. Novo FEN: ${chessBoard.fen()}`);

                // Verifica o estado do jogo (checkmate, empate)
                if (chessBoard.in_checkmate()) {
                    io.to(gameId).emit('gameOver', { winner: chessBoard.turn() === 'w' ? 'black' : 'white', reason: 'checkmate' });
                    console.log(`Partida ${gameId} terminada: Xeque-mate.`);
                    delete games[gameId]; // Remove a partida
                } else if (chessBoard.in_draw() || chessBoard.in_stalemate() || chessBoard.in_threefold_repetition() || chessBoard.insufficient_material()) {
                    io.to(gameId).emit('gameOver', { winner: 'draw', reason: 'draw' });
                    console.log(`Partida ${gameId} terminada: Empate.`);
                    delete games[gameId]; // Remove a partida
                }

            } else {
                // Se o movimento for inválido, notifica apenas o jogador que tentou
                console.log(`Tentativa de movimento inválido na partida ${gameId}: ${from}-${to}`);
                socket.emit('invalidMove', 'Movimento inválido!');
            }
        } catch (e) {
            console.error(`Erro ao processar movimento na partida ${gameId}: ${e.message}`);
            socket.emit('error', 'Erro interno ao processar movimento.');
        }
    });

    // Lida com a desconexão de um usuário
    socket.on('disconnect', () => {
        console.log(`User disconnected: ${socket.id}`);
        // Se o jogador desconectado estava esperando, remove-o
        if (pendingPlayer && pendingPlayer.id === socket.id) {
            pendingPlayer = null;
            console.log('Jogador pendente desconectado.');
        } else {
            // Se o jogador desconectado estava em uma partida, notifica o oponente
            for (const gameId in games) {
                if (games[gameId].players.white === socket.id || games[gameId].players.black === socket.id) {
                    const opponentId = games[gameId].players.white === socket.id ? games[gameId].players.black : games[gameId].players.white;
                    io.to(opponentId).emit('opponentDisconnected', 'Seu oponente desconectou. A partida terminou.');
                    console.log(`Oponente ${opponentId} notificado da desconexão na partida ${gameId}.`);
                    delete games[gameId]; // Remove a partida
                    break;
                }
            }
        }
    });
});

server.listen(PORT, () => {
    console.log(`Servidor de Xadrez escutando na porta ${PORT}`);
});