 <div class="botao-menu"> <i class="fa-solid fa-bars"></i>
 </div>
  
 <nav class="menu-lateral">
     <ul>
         <li>
             <a class="Jogar" href="./play-online.php">
                 <span>Jogar</span> </a>
         </li>
         <li>
             <a class="Problema">
                 <span>Problemas diários</span>
             </a>
         </li>
         <li>
             <a class="Aprender" href="./learn-chess.php">
                 <span>Aprender</span>
             </a>
         </li>
     </ul>
 </nav>
 <div class="background"></div>
 <script src="./sidebar.js"></script>