const chessBoard = document.querySelector(".chessBoard");

let line1 = 
[
    "<div src='./White-Rook.png' class='square white t11 rook'><img src='./White-Rook.png' class='piece'></div> ",
    "<div src='./White-Knight.png' class='square black t12 knight'><img src='./White-Knight.png' class='piece'></div>",
    "<div src='./White-Bishop.png' class='square white t13 bishop'><img src='./White-Bishop.png' class='piece'></div>",
    "<div src='./White-Queen.png' class='square black t14 queen'><img src='./White-Queen.png' class='piece'></div>",
    "<div src='./White-King.png' class='square white t15 king'><img src='./White-King.png' class='piece'></div>",
    "<div src='./White-Bishop.png' class='square black t16 bishop'><img src='./White-Bishop.png' class='piece'></div>",
    "<div src='./White-Knight.png' class='square white t17 knight'><img src='./White-Knight.png' class='piece'></div>",
    "<div src='./White-Rook.png' class='square black t18 rook'><img src='./White-Rook.png' class='piece'></div>"
];
let line2 = 
[
    "<div src='./White-Pawn.png' class='square black t21 pawn'><img src='./White-Pawn.png'  class='piece'></div>",
    "<div src='./White-Pawn.png' class='square white t22 pawn'><img src='./White-Pawn.png'  class='piece'></div>",
    "<div src='./White-Pawn.png' class='square black t23 pawn'><img src='./White-Pawn.png'  class='piece'></div>",
    "<div src='./White-Pawn.png' class='square white t24 pawn'><img src='./White-Pawn.png'  class='piece'></div>",
    "<div src='./White-Pawn.png' class='square black t25 pawn'><img src='./White-Pawn.png'  class='piece'></div>",
    "<div src='./White-Pawn.png' class='square white t26 pawn'><img src='./White-Pawn.png'  class='piece'></div>",
    "<div src='./White-Pawn.png' class='square black t27 pawn'><img src='./White-Pawn.png'  class='piece'></div>",
    "<div src='./White-Pawn.png' class='square white t28 pawn'><img src='./White-Pawn.png'  class='piece'></div>"
];
let line3 = 
[
    "<div src='' class='square white t31' ><img src='' class='piece'></div>",
    "<div src='' class='square black t32' ><img src='' class='piece'></div>",
    "<div src='' class='square white t33' ><img src='' class='piece'></div>",
    "<div src='' class='square black t34' ><img src='' class='piece'></div>",
    "<div src='' class='square white t35' ><img src='' class='piece'></div>",
    "<div src='' class='square black t36' ><img src='' class='piece'></div>",
    "<div src='' class='square white t37' ><img src='' class='piece'></div>",
    "<div src='' class='square black t38' ><img src='' class='piece'></div>"
];
let line4 = 
[
    "<div src='' class='square black t41' ><img src='' class='piece'></div>",
    "<div src='' class='square white t42' ><img src='' class='piece'></div>",
    "<div src='' class='square black t43' ><img src='' class='piece'></div>",
    "<div src='' class='square white t44' ><img src='' class='piece'></div>",
    "<div src='' class='square black t45' ><img src='' class='piece'></div>",
    "<div src='' class='square white t46' ><img src='' class='piece'></div>",
    "<div src='' class='square black t47' ><img src='' class='piece'></div>",
    "<div src='' class='square white t48' ><img src='' class='piece'></div>"
];
let line5 = 
[
    "<div src='' class='square white t51' ><img src='' class='piece'></div>",
    "<div src='' class='square black t52' ><img src='' class='piece'></div>",
    "<div src='' class='square white t53' ><img src='' class='piece'></div>",
    "<div src='' class='square black t54' ><img src='' class='piece'></div>",
    "<div src='' class='square white t55' ><img src='' class='piece'></div>",
    "<div src='' class='square black t56' ><img src='' class='piece'></div>",
    "<div src='' class='square white t57' ><img src='' class='piece'></div>",
    "<div src='' class='square black t58' ><img src='' class='piece'></div>"
];
let line6 = 
[
    "<div src='' class='square black t61' ><img src='' class='piece'></div>",
    "<div src='' class='square white t62' ><img src='' class='piece'></div>",
    "<div src='' class='square black t63' ><img src='' class='piece'></div>",
    "<div src='' class='square white t64' ><img src='' class='piece'></div>",
    "<div src='' class='square black t65' ><img src='' class='piece'></div>",
    "<div src='' class='square white t66' ><img src='' class='piece'></div>",
    "<div src='' class='square black t67' ><img src='' class='piece'></div>",
    "<div src='' class='square white t68' ><img src='' class='piece'></div>"
];
let line7 = 
[
    "<div src='./Black-Pawn.png' class='square white t71 pawn'><img src='./Black-Pawn.png' class='piece'></div>",
    "<div src='./Black-Pawn.png' class='square black t72 pawn'><img src='./Black-Pawn.png' class='piece'></div>",
    "<div src='./Black-Pawn.png' class='square white t73 pawn'><img src='./Black-Pawn.png' class='piece'></div>",
    "<div src='./Black-Pawn.png' class='square black t74 pawn'><img src='./Black-Pawn.png' class='piece'></div>",
    "<div src='./Black-Pawn.png' class='square white t75 pawn'><img src='./Black-Pawn.png' class='piece'></div>",
    "<div src='./Black-Pawn.png' class='square black t76 pawn'><img src='./Black-Pawn.png' class='piece'></div>",
    "<div src='./Black-Pawn.png' class='square white t77 pawn'><img src='./Black-Pawn.png' class='piece'></div>",
    "<div src='./Black-Pawn.png' class='square black t78 pawn'><img src='./Black-Pawn.png' class='piece'></div>"
];
let line8 = 
[
    "<div src='./Black-Rook.png' class='square black t81 rook' ><img src='./Black-Rook.png' class='piece'></div>",
    "<div src='./Black-Knight.png' class='square white t82 knight' ><img src='./Black-Knight.png' class='piece'></div>",
    "<div src='./Black-Bishop.png' class='square black t83 bishop' ><img src='./Black-Bishop.png' class='piece'></div>",
    "<div src='./Black-Queen.png' class='square white t84 queen' ><img src='./Black-Queen.png' class='piece'></div>",
    "<div src='./Black-King.png' class='square black t85 king' ><img src='./Black-King.png' class='piece'></div>",
    "<div src='./Black-Bishop.png' class='square white t86 bishop' ><img src='./Black-Bishop.png' class='piece'></div>",
    "<div src='./Black-Knight.png' class='square black t87 knight' ><img src='./Black-Knight.png' class='piece'></div>",
    "<div src='./Black-Rook.png' class='square white t88 rook' ><img src='./Black-Rook.png' class='piece'></div>"
];
let squaresLine = [line1,line2,line3,line4,line5,line6,line7,line8];
let currentPlayer = "White";
function createElementsChess(){
   
    for (let i = 0; i < 8; i++) {
       
        
        
        const linhaUm = document.querySelector(".line-1")
        const linhaDois = document.querySelector(".line-2")
        const linhaTres = document.querySelector(".line-3")
        const linhaQuatro = document.querySelector(".line-4")
        const linhaCinco = document.querySelector(".line-5")
        const linhaSeis = document.querySelector(".line-6")
        const linhaSete = document.querySelector(".line-7")
        const linhaOito = document.querySelector(".line-8")                                                                                                                                                                                                                                                                                                                 
        /*linhaOito.innerHTML = 
        squaresLine[0][0] + 
        squaresLine[0][1] + 
        squaresLine[0][2] + 
        squaresLine[0][3] + 
        squaresLine[0][4] + 
        squaresLine[0][5] + 
        squaresLine[0][6] + 
        squaresLine[0][7];
        linhaSete.innerHTML = 
        squaresLine[1][0] + 
        squaresLine[1][1] + 
        squaresLine[1][2] + 
        squaresLine[1][3] + 
        squaresLine[1][4] + 
        squaresLine[1][5] + 
        squaresLine[1][6] + 
        squaresLine[1][7];
        linhaSeis.innerHTML = 
        squaresLine[2][0] + 
        squaresLine[2][1] + 
        squaresLine[2][2] + 
        squaresLine[2][3] + 
        squaresLine[2][4] + 
        squaresLine[2][5] + 
        squaresLine[2][6] + 
        squaresLine[2][7];
        linhaCinco.innerHTML = 
        squaresLine[3][0] + 
        squaresLine[3][1] + 
        squaresLine[3][2] + 
        squaresLine[3][3] + 
        squaresLine[3][4] + 
        squaresLine[3][5] + 
        squaresLine[3][6] + 
        squaresLine[3][7];
        linhaQuatro.innerHTML = 
        squaresLine[4][0] + 
        squaresLine[4][1] + 
        squaresLine[4][2] + 
        squaresLine[4][3] + 
        squaresLine[4][4] + 
        squaresLine[4][5] + 
        squaresLine[4][6] + 
        squaresLine[4][7];
        linhaTres.innerHTML = 
        squaresLine[5][0] + 
        squaresLine[5][1] + 
        squaresLine[5][2] + 
        squaresLine[5][3] + 
        squaresLine[5][4] + 
        squaresLine[5][5] + 
        squaresLine[5][6] + 
        squaresLine[5][7];
        linhaDois.innerHTML = 
        squaresLine[6][0] + 
        squaresLine[6][1] + 
        squaresLine[6][2] + 
        squaresLine[6][3] + 
        squaresLine[6][4] + 
        squaresLine[6][5] + 
        squaresLine[6][6] + 
        squaresLine[6][7];
        linhaUm.innerHTML = 
        squaresLine[7][0] + 
        squaresLine[7][1] + 
        squaresLine[7][2] + 
        squaresLine[7][3] + 
        squaresLine[7][4] + 
        squaresLine[7][5] + 
        squaresLine[7][6] + 
        squaresLine[7][7];*/
        chessBoard.innerHTML = squaresLine[0][0] + 
        squaresLine[0][1] + 
        squaresLine[0][2] + 
        squaresLine[0][3] + 
        squaresLine[0][4] + 
        squaresLine[0][5] + 
        squaresLine[0][6] + 
        squaresLine[0][7] + 
squaresLine[1][0] + 
        squaresLine[1][1] + 
        squaresLine[1][2] + 
        squaresLine[1][3] + 
        squaresLine[1][4] + 
        squaresLine[1][5] + 
        squaresLine[1][6] + 
        squaresLine[1][7] + 
squaresLine[2][0] + 
        squaresLine[2][1] + 
        squaresLine[2][2] + 
        squaresLine[2][3] + 
        squaresLine[2][4] + 
        squaresLine[2][5] + 
        squaresLine[2][6] + 
        squaresLine[2][7] + 
squaresLine[3][0] + 
        squaresLine[3][1] + 
        squaresLine[3][2] + 
        squaresLine[3][3] + 
        squaresLine[3][4] + 
        squaresLine[3][5] + 
        squaresLine[3][6] + 
        squaresLine[3][7]   + 
squaresLine[4][0] + 
        squaresLine[4][1] + 
        squaresLine[4][2] + 
        squaresLine[4][3] + 
        squaresLine[4][4] + 
        squaresLine[4][5] + 
        squaresLine[4][6] + 
        squaresLine[4][7] + 
squaresLine[5][0] + 
        squaresLine[5][1] + 
        squaresLine[5][2] + 
        squaresLine[5][3] + 
        squaresLine[5][4] + 
        squaresLine[5][5] + 
        squaresLine[5][6] + 
        squaresLine[5][7] + 
 squaresLine[6][0] + 
        squaresLine[6][1] + 
        squaresLine[6][2] + 
        squaresLine[6][3] + 
        squaresLine[6][4] + 
        squaresLine[6][5] + 
        squaresLine[6][6] + 
        squaresLine[6][7] + 
 squaresLine[7][0] + 
        squaresLine[7][1] + 
        squaresLine[7][2] + 
        squaresLine[7][3] + 
        squaresLine[7][4] + 
        squaresLine[7][5] + 
        squaresLine[7][6] + 
        squaresLine[7][7];
    }
    
}
createElementsChess();
moveAndPieces();
function moveAndPieces(){
const movePawn = document.querySelectorAll(".pawn");
const moveKnight = document.querySelectorAll(".knight");
const moveBishop = document.querySelectorAll(".bishop");
const moveQueen = document.querySelectorAll(".queen");
const moveKing  = document.querySelectorAll(".king");
const piecesBoard = document.getElementsByClassName("piece");
const squareBoard = document.getElementsByClassName("square");
const piecesImages = document.getElementsByTagName("img");

}
