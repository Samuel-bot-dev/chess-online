// chess-server/server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Chess } = require('chess.js');

const app = express();
const server = http.createServer(app);

// >>>>>>>>>>> ADICIONE ESTA LINHA AQUI <<<<<<<<<<<
const PORT = process.env.PORT || 3000; // Define a porta, usando a variável de ambiente ou 3000 como padrão
// >>>>>>>>>>> FIM DA ADIÇÃO <<<<<<<<<<<

// Configura o Socket.IO para permitir conexões de qualquer origem (CORS)
const io = new Server(server, {
    cors: {
        origin: "*", // Permite conexões de qualquer domínio (cuidado em produção!)
        methods: ["GET", "POST"]
    }
});

let games = {}; // Objeto para armazenar as partidas ativas
let pendingPlayer = null; // Armazena um jogador esperando por uma partida

io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    // Lógica de emparelhamento simples
    if (pendingPlayer) {
        const gameId = `game-${pendingPlayer.id}-${socket.id}`;
        const chessGame = new Chess();
        games[gameId] = {
            players: {
                white: pendingPlayer.id,
                black: socket.id
            },
            board: chessGame,
        };

        socket.join(gameId);
        pendingPlayer.socket.join(gameId);

        pendingPlayer.socket.emit('matchFound', {
            gameId: gameId,
            playerColor: 'w',
            opponentId: socket.id
        });
        socket.emit('matchFound', {
            gameId: gameId,
            playerColor: 'b',
            opponentId: pendingPlayer.id
        });

        console.log(`Match found: ${gameId} (White: ${pendingPlayer.id}, Black: ${socket.id})`);
        pendingPlayer = null;

    } else {
        pendingPlayer = {
            id: socket.id,
            socket: socket
        };
        socket.emit('waitingForOpponent', 'Waiting for an opponent...');
        console.log(`Player ${socket.id} is waiting for an opponent.`);
    }

    socket.on('move', (data) => {
        const { gameId, from, to, promotion, playerColor } = data;
        const game = games[gameId];

        if (!game) {
            console.warn(`Game ${gameId} not found for move.`);
            return;
        }

        const chessBoard = game.board;

        if ((playerColor === 'w' && chessBoard.turn() !== 'w') || (playerColor === 'b' && chessBoard.turn() !== 'b')) {
            console.log(`Not ${playerColor}'s turn in game ${gameId}.`);
            socket.emit('invalidMove', 'Não é o seu turno!');
            return;
        }

        const piece = chessBoard.get(from);
        if (!piece || piece.color !== playerColor) {
            console.log(`Player ${socket.id} tried to move opponent's piece or empty square.`);
            socket.emit('invalidMove', 'Você não pode mover essa peça.');
            return;
        }

        try {
            const moveResult = chessBoard.move({ from, to, promotion });

            if (moveResult) {
                io.to(gameId).emit('moveMade', {
                    fen: chessBoard.fen(),
                    lastMove: moveResult,
                    turn: chessBoard.turn()
                });
                console.log(`Move made in game ${gameId}: ${from}-${to}. New FEN: ${chessBoard.fen()}`);

                if (chessBoard.in_checkmate()) {
                    io.to(gameId).emit('gameOver', { winner: chessBoard.turn() === 'w' ? 'black' : 'white', reason: 'checkmate' });
                    console.log(`Game ${gameId} ended: Checkmate.`);
                    delete games[gameId];
                } else if (chessBoard.in_draw() || chessBoard.in_stalemate() || chessBoard.in_threefold_repetition() || chessBoard.insufficient_material()) {
                    io.to(gameId).emit('gameOver', { winner: 'draw', reason: 'draw' });
                    console.log(`Game ${gameId} ended: Draw.`);
                    delete games[gameId];
                }

            } else {
                console.log(`Invalid move attempt in game ${gameId}: ${from}-${to}`);
                socket.emit('invalidMove', 'Movimento inválido!');
            }
        } catch (e) {
            console.error(`Error processing move in game ${gameId}: ${e.message}`);
            socket.emit('error', 'Erro interno ao processar movimento.');
        }
    });

    socket.on('disconnect', () => {
        console.log(`User disconnected: ${socket.id}`);
        if (pendingPlayer && pendingPlayer.id === socket.id) {
            pendingPlayer = null;
            console.log('Pending player disconnected.');
        } else {
            for (const gameId in games) {
                if (games[gameId].players.white === socket.id || games[gameId].players.black === socket.id) {
                    const opponentId = games[gameId].players.white === socket.id ? games[gameId].players.black : games[gameId].players.white;
                    io.to(opponentId).emit('opponentDisconnected', 'Seu oponente desconectou. A partida terminou.');
                    console.log(`Opponent ${opponentId} notified of disconnection in game ${gameId}.`);
                    delete games[gameId];
                    break;
                }
            }
        }
    });
});

// >>>>>>>>>>> AQUI TAMBÉM É ONDE O SERVER ESTÁ ESCUTANDO A PORTA <<<<<<<<<<<
server.listen(PORT, () => {
    console.log(`Chess server listening on port ${PORT}`);
});