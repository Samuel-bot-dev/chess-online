<?php
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'chess';

$conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);




?>